module.exports = {
  globals: {
    device: true,
    element: true,
    by: true,
    waitFor: true,
  },
};
