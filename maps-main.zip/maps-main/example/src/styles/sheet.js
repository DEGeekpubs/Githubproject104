import { StyleSheet } from 'react-native';

const styles = {};

styles.matchParent = {
  flex: 1,
};

export default StyleSheet.create(styles);
