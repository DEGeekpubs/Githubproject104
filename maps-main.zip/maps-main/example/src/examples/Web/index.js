export { default as MarkerView } from './MarkerView';

export const metadata = {
  title: 'Web',
};
