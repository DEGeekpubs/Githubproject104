// see https://github.com/rnmapbox/maps/pull/3310

import Foundation
