package com.rnmapbox.rnmbx.components.annotation

import android.content.Context
import com.facebook.react.views.view.ReactViewGroup

class RNMBXCallout(context: Context?) : ReactViewGroup(context)