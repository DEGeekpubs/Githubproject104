package com.rnmapbox.rnmbx.v11compat.feature;

import com.mapbox.geojson.Feature;

import com.mapbox.maps.QueriedFeature as _QueriedFeature;

typealias QueriedRenderedFeature = _QueriedFeature;

typealias QueriedSourceFeature = _QueriedFeature;

