package com.rnmapbox.rnmbx.v11compat.layer;

import com.mapbox.maps.extension.style.layers.Layer

fun Layer.slot(slot: String) {
    // V11 only
}