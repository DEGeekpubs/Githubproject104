package com.rnmapbox.rnmbx.v11compat.layer;

import com.mapbox.maps.extension.style.layers.Layer
