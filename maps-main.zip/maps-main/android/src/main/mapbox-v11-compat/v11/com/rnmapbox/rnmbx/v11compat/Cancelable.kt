package com.rnmapbox.rnmbx.v11compat

typealias Cancelable = com.mapbox.common.Cancelable;