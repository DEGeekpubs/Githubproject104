module.exports = require('./plugin/build/withMapbox');
